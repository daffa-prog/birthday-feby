// Website kejutan ulang tahun untuk Feby
// Untuk mengganti foto, letakkan foto di folder images dengan nama yang sama seperti pada index.html.

const screens = [...document.querySelectorAll('.screen')];
const petalLayer = document.getElementById('petalLayer');
const giftButton = document.getElementById('openGift');
const youtubePlayer = document.querySelector('.youtube-player');
const musicToggle = document.getElementById('musicToggle');
const youtubeFrame = document.getElementById('youtubeFrame');

function showScreen(id) {
  screens.forEach(screen => {
    const active = screen.id === id;
    screen.classList.toggle('active', active);
    screen.setAttribute('aria-hidden', String(!active));
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (id === 'greeting' || id === 'letter' || id === 'gallery' || id === 'ending') {
    document.body.classList.add('has-opened');
  }
}

document.querySelectorAll('[data-go]').forEach(button => {
  button.addEventListener('click', () => {
    const target = button.dataset.go;
    if (target === 'home') {
      giftButton.classList.remove('opening');
      showScreen('home');
      return;
    }
    showScreen(target);
    if (target === 'ending') burstPetals(45);
  });
});

giftButton.addEventListener('click', () => {
  if (giftButton.classList.contains('opening')) return;
  giftButton.classList.add('opening');
  burstPetals(190);
  // Beri waktu agar animasi tutup kado terlihat sebelum berpindah ke ucapan.
  // YouTube tidak selalu mengizinkan autoplay dengan suara; gunakan tombol Music.
  setTimeout(() => {
    showScreen('greeting');
    giftButton.classList.remove('opening');
  }, 900);
});

musicToggle.addEventListener('click', () => {
  youtubePlayer.classList.toggle('visible');
  musicToggle.setAttribute('aria-expanded', String(youtubePlayer.classList.contains('visible')));
  if (youtubePlayer.classList.contains('visible')) {
    youtubePlayer.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
  }
});

// Surat dibagi menjadi 6 slide agar lebih nyaman dibaca.
const letterSlides = [
  [
    'Happy birthday, my love. ❤️',
    'Selamat ulang tahun yang ke-22 untuk seseorang yang sudah menjadi bagian dari perjalanan hidupku selama lebih dari 5 tahun ini.',
    'Kalau dipikir-pikir, waktu berjalan begitu cepat. Rasanya baru kemarin kita masih sama-sama duduk di bangku kelas 11 MAN, masih sama-sama belajar, masih belum tahu akan sejauh apa perjalanan kita. Tapi ternyata, sampai hari ini kita masih bersama. Dari masa MAN, melewati banyak cerita, sampai sekarang kita sudah sama-sama berada di semester 7 perkuliahan.'
  ],
  [
    'Selama lebih dari 5 tahun ini, mungkin kita sudah banyak berubah. Kita pernah bahagia, pernah berantem, pernah salah paham, pernah kecewa, pernah saling menguatkan, dan mungkin ada juga masa-masa di mana kita sama-sama merasa lelah. Tapi dari semua itu, aku bersyukur kita masih memilih untuk tetap bertahan dan berjalan bersama sampai sejauh ini.',
    'Aku nggak tahu nanti perjalanan kita akan seperti apa, tapi untuk hari ini aku cuma ingin kamu tahu bahwa aku benar-benar bersyukur pernah dan masih bisa menjadi bagian dari hidup kamu.'
  ],
  [
    'Di umur kamu yang ke-22 ini, aku nggak mau cuma mendoakan kamu supaya bahagia hari ini. Aku ingin kamu selalu sehat, dipanjangkan umur, dilancarkan semua kegiatan dan urusanmu, dimudahkan setiap langkah yang kamu ambil, dan diberikan kekuatan ketika menghadapi hal-hal yang nggak mudah.',
    'Semoga semua yang sedang kamu perjuangkan sekarang bisa mendapatkan hasil yang baik. Semoga apa yang kamu inginkan, apa yang kamu impikan, dan apa yang selama ini kamu doakan, perlahan-lahan bisa Allah wujudkan di waktu yang paling tepat.'
  ],
  [
    'Kalau suatu hari nanti kamu merasa capek, merasa tertinggal, atau merasa semuanya terlalu berat, aku harap kamu ingat bahwa kamu sudah sejauh ini. Kamu sudah melewati banyak hal yang dulu mungkin kamu pikir nggak akan sanggup kamu lewati. Jadi jangan terlalu keras sama diri kamu sendiri.',
    'Aku juga berharap di umur 22 ini kamu bisa lebih banyak menemukan alasan untuk tersenyum, lebih banyak merasakan ketenangan, dan lebih sering merasa bangga dengan diri kamu sendiri.'
  ],
  [
    'Terima kasih sudah menjadi bagian dari hidupku selama lebih dari 5 tahun. Terima kasih untuk semua waktu, cerita, perhatian, kesabaran, dan hal-hal kecil yang mungkin sering nggak sempat aku ucapkan terima kasihnya.',
    'Kita mungkin nggak selalu menjadi pasangan yang sempurna, tapi aku bersyukur pernah melewati masa-masa itu bersama kamu. Dari dua orang yang dulu masih sama-sama di kelas 11 MAN, sampai sekarang sudah sama-sama berjuang menyelesaikan perkuliahan di semester 7.',
    'Semoga tahun ini menjadi salah satu tahun terbaik dalam hidup kamu. Semoga langkah kamu selalu dipermudah, rezeki kamu dilancarkan, hati kamu ditenangkan, dan semua hal baik selalu menemukan jalan untuk datang kepada kamu.'
  ],
  [
    'Dan untuk perjalanan kita ke depannya, aku nggak berani menjanjikan semuanya akan selalu mudah. Tapi selama kita masih sama-sama mau belajar, saling memahami, dan saling menjaga, aku berharap kita masih bisa terus berjalan dan melihat sejauh apa cerita ini akan membawa kita.',
    'Happy 22nd birthday, my love. ❤️',
    'Semoga kamu selalu sehat. Semoga kamu selalu bahagia. Semoga semua impian kamu tercapai. Dan semoga di setiap langkah yang kamu ambil, selalu ada hal baik yang menunggu di depan sana.',
    'Terima kasih sudah menjadi kamu. Dan terima kasih karena selama lebih dari 5 tahun ini, kamu sudah menjadi salah satu bagian terpenting dalam perjalanan hidupku.',
    'I love you, more than words can explain. ❤️'
  ]
];

let currentSlide = 0;
const letterContent = document.getElementById('letterContent');
const slideCount = document.getElementById('slideCount');
const slideDots = document.getElementById('slideDots');
const prevSlide = document.getElementById('prevSlide');
const nextSlide = document.getElementById('nextSlide');

function renderSlide() {
  letterContent.style.animation = 'none';
  void letterContent.offsetWidth;
  letterContent.style.animation = '';
  letterContent.innerHTML = letterSlides[currentSlide].map((paragraph, index) => {
    const className = (currentSlide === 5 && index === 4) ? ' class="highlight"' : '';
    return `<p${className}>${escapeHTML(paragraph)}</p>`;
  }).join('');
  slideCount.textContent = `${String(currentSlide + 1).padStart(2, '0')} / ${String(letterSlides.length).padStart(2, '0')}`;
  prevSlide.disabled = currentSlide === 0;
  prevSlide.style.opacity = currentSlide === 0 ? '.45' : '1';
  nextSlide.textContent = currentSlide === letterSlides.length - 1 ? 'Lihat kenangan →' : 'Lanjutkan →';
  [...slideDots.children].forEach((dot, index) => {
    dot.classList.toggle('active', index === currentSlide);
    dot.setAttribute('aria-current', index === currentSlide ? 'step' : 'false');
  });
}
function escapeHTML(value) {
  return value.replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  }[char]));
}
letterSlides.forEach((_, index) => {
  const dot = document.createElement('button');
  dot.type = 'button';
  dot.className = 'slide-dot';
  dot.setAttribute('aria-label', `Buka bagian surat ${index + 1}`);
  dot.addEventListener('click', () => { currentSlide = index; renderSlide(); });
  slideDots.appendChild(dot);
});
prevSlide.addEventListener('click', () => {
  if (currentSlide > 0) { currentSlide--; renderSlide(); }
});
nextSlide.addEventListener('click', () => {
  if (currentSlide < letterSlides.length - 1) {
    currentSlide++;
    renderSlide();
  } else {
    showScreen('gallery');
    burstPetals(35);
  }
});
renderSlide();

// Animasi kelopak bunga. Jumlah besar hanya dipicu saat kado dibuka.
const petalColors = ['#b92337', '#d94355', '#ef9da8', '#f5c4ca', '#e6ae48', '#fff0d7', '#e87583'];
function burstPetals(amount) {
  for (let i = 0; i < amount; i++) {
    const petal = document.createElement('span');
    petal.className = 'petal';
    const size = 8 + Math.random() * 15;
    petal.style.left = `${Math.random() * 100}%`;
    petal.style.width = `${size}px`;
    petal.style.height = `${size * (1.1 + Math.random() * .7)}px`;
    petal.style.background = petalColors[Math.floor(Math.random() * petalColors.length)];
    petal.style.setProperty('--drift', `${Math.random() * 260 - 130}px`);
    petal.style.setProperty('--spin', `${Math.random() * 1000 - 500}deg`);
    petal.style.animationDuration = `${3.5 + Math.random() * 5.5}s`;
    petal.style.animationDelay = `${Math.random() * 1.4}s`;
    petalLayer.appendChild(petal);
    petal.addEventListener('animationend', () => petal.remove(), { once: true });
  }
}

// Akses keyboard sederhana: Escape menutup pemutar YouTube.
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') youtubePlayer.classList.remove('visible');
});
